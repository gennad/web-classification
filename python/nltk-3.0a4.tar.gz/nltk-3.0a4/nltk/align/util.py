# Natural Language Toolkit: Aligner Utilities
#
# Copyright (C) 2001-2013 NLTK Project
# Author: 
# URL: <http://www.nltk.org/>
# For license information, see LICENSE.TXT

